package sn.dakar.uvs.tp1

case class Person(age:Int, rattrapage:Int)